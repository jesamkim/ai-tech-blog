"""Resolve exact public checkpoints and download weights before inference."""
import datetime, json, time
from pathlib import Path
from huggingface_hub import HfApi, snapshot_download

ROOT=Path(__file__).resolve().parent
plan=json.loads((ROOT/'plan.json').read_text())
api=HfApi()
records=[]
for model_id in plan['model_ids']:
    start=time.perf_counter()
    revision=api.model_info(model_id).sha
    checkpoint=Path(snapshot_download(model_id, revision=revision))
    config_path=checkpoint/'strands_decider_config.json'
    if not config_path.exists(): config_path=checkpoint/'hobson_config.json'
    config=json.loads(config_path.read_text())
    provenance=json.loads((checkpoint/'provenance.json').read_text()) if (checkpoint/'provenance.json').exists() else {}
    base_model=config['base_model']
    base_revision=config.get('base_revision') or provenance.get('base_model_revision')
    if not base_revision: raise ValueError('Refuse unpinned base model')
    snapshot_download(base_model,revision=base_revision,allow_patterns=['*.safetensors','*.json','*.jinja','*.model','*.txt'])
    record={'model_id':model_id,'revision':revision,'checkpoint':str(checkpoint),'base_model':base_model,'base_revision':base_revision,'download_or_cache_resolution_seconds':time.perf_counter()-start,'config':config,'resolved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    records.append(record)
    (ROOT/'models_resolved_private.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
    public=[{k:v for k,v in r.items() if k!='checkpoint'} for r in records]
    (ROOT/'models_resolved.json').write_text(json.dumps(public,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(public[-1],ensure_ascii=False),flush=True)
