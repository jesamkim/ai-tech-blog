"""Frozen synthetic probe. Run one model per fresh process; no HTTP server."""
import argparse, dataclasses, datetime, hashlib, importlib.metadata, inspect, json, math, os, platform, statistics, subprocess, sys, time, traceback
from pathlib import Path

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--model',choices=['v19','v21'],required=True)
args=parser.parse_args()
OUT=ROOT/'results'/args.model
OUT.mkdir(parents=True,exist_ok=True)

def write_json(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

def emit(obj):
    obj['recorded_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT/'raw.jsonl').open('a') as f:f.write(json.dumps(obj,ensure_ascii=False)+'\n')
    print(json.dumps({k:v for k,v in obj.items() if k not in ['request','response','traceback']},ensure_ascii=False),flush=True)

manifest=json.loads((ROOT/'frozen_manifest.json').read_text())
for name,digest in manifest['sha256'].items():
    if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:raise ValueError(f'Frozen file modified: {name}')
if (OUT/'raw.jsonl').exists():raise FileExistsError('Refusing to overwrite previous raw results')
plan=json.loads((ROOT/'plan.json').read_text())
dataset=json.loads((ROOT/'dataset.json').read_text())
resolved=next(r for r in json.loads((ROOT/'models_resolved_private.json').read_text()) if r['model_id'].endswith(args.model))

import torch
import numpy as np
import strands_decider
from strands_decider.infer import load_engine
from strands_decider.schema import SystemOneRequest
from strands_decider.prompting import render_state,render_question
from transformers.models.qwen3_5 import modeling_qwen3_5 as qwen

def symbol_info(name):
    obj=getattr(qwen,name,None)
    if obj is None:return None
    result={'module':getattr(obj,'__module__',None),'name':getattr(obj,'__qualname__',type(obj).__name__)}
    queue=[obj];seen=set();implementations=[]
    while queue:
        func=queue.pop()
        if id(func) in seen or not inspect.isfunction(func):continue
        seen.add(id(func))
        nonlocals=inspect.getclosurevars(func).nonlocals
        if 'implementation' in nonlocals:
            impl=nonlocals['implementation']
            implementations.append({'module':getattr(impl,'__module__',None),'name':getattr(impl,'__qualname__',type(impl).__name__),'optimized_package_selected':nonlocals.get('is_new_implementation')})
        queue.extend(v for v in nonlocals.values() if inspect.isfunction(v))
        if hasattr(func,'__wrapped__'):queue.append(func.__wrapped__)
    result['selected_implementations']=implementations
    return result

versions={}
for pkg in ['torch','transformers','peft','flash-linear-attention','causal-conv1d','triton','numpy','huggingface-hub','strands-decider']:
    try: versions[pkg]=importlib.metadata.version(pkg)
    except importlib.metadata.PackageNotFoundError:versions[pkg]=None
source_root=(ROOT/'source').resolve()
imported_package=Path(strands_decider.__file__).resolve()
expected_package=source_root/'src'/'strands_decider'/'__init__.py'
if imported_package!=expected_package:raise ValueError('Imported strands_decider is outside pinned source checkout')
source_commit=subprocess.check_output(['git','-C',str(source_root),'rev-parse','HEAD'],text=True).strip()
source_status=subprocess.check_output(['git','-C',str(source_root),'status','--porcelain'],text=True)
if source_commit!=plan['source_commit']:raise ValueError('Source commit differs from frozen plan')
if source_status:raise ValueError('Source checkout has local changes')
provenance={'imported_package_relative_to_experiment':str(imported_package.relative_to(ROOT)), 'imported_package_is_pinned_checkout':True,'source_clean':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'module_sha256':{str(p.relative_to(source_root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((source_root/'src'/'strands_decider').rglob('*.py'))}}
metadata={'execution_provenance':provenance,'model':args.model,'model_id':resolved['model_id'],'checkpoint_revision':resolved['revision'],'base_model':resolved['base_model'],'base_revision':resolved['base_revision'],'source_commit':subprocess.check_output(['git','-C',str(ROOT/'source'),'rev-parse','HEAD'],text=True).strip(),'python':platform.python_version(),'platform':platform.platform(),'packages':versions,'gpu':torch.cuda.get_device_name(0),'gpu_total_bytes':torch.cuda.get_device_properties(0).total_memory,'torch_cuda':torch.version.cuda,'gpu_driver':subprocess.check_output(['nvidia-smi','--query-gpu=driver_version','--format=csv,noheader'],text=True).strip(),'cpu':subprocess.check_output(['lscpu'],text=True),'kernel_symbols':{n:symbol_info(n) for n in ['causal_conv1d_fn','causal_conv1d_update','torch_chunk_gated_delta_rule','torch_recurrent_gated_delta_rule']},'qwen_fast_path_available':getattr(qwen,'is_fast_path_available',None),'seed':42,'deterministic_algorithms':torch.are_deterministic_algorithms_enabled(),'allow_tf32_matmul':torch.backends.cuda.matmul.allow_tf32,'allow_tf32_cudnn':torch.backends.cudnn.allow_tf32,'measurement_scope':'Python direct SystemOneEngine.evaluate; wall clock, CUDA synchronized; request validation outside timed region; engine tokenization inside; no HTTP/network time','frozen_manifest':manifest}
checkpoint_dir=Path(resolved['checkpoint'])
metadata['checkpoint_file_sha256']={str(p.relative_to(checkpoint_dir)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(checkpoint_dir.rglob('*')) if p.is_file() and (p.suffix in ['.safetensors','.pt'] or p.name in ['strands_decider_config.json','hobson_config.json','adapter_config.json','provenance.json','tokenizer.json','tokenizer_config.json'])}
metadata['optimized_kernel_selection_verified']=all(any(v.get('optimized_package_selected') is True for v in info['selected_implementations']) for info in metadata['kernel_symbols'].values() if info is not None)
torch.manual_seed(42);np.random.seed(42)
write_json(OUT/'metadata.json',metadata)
emit({'phase':'environment','model':args.model,'kernel_symbols':metadata['kernel_symbols'],'fast_path':metadata['qwen_fast_path_available']})

try:
    t=time.perf_counter()
    engine=load_engine(resolved['checkpoint'],device='cuda',use_prefix_cache=True)
    engine.model.config.max_length=plan['max_length']
    engine.cfg.strict_window=True
    engine.cfg.max_batch=1
    torch.cuda.synchronize()
    load_seconds=time.perf_counter()-t
    metadata['load_seconds']=load_seconds
    metadata['effective_config']=dataclasses.asdict(engine.model.config)
    metadata['torso_dtype']=str(next(engine.model.torso.parameters()).dtype)
    metadata['attention_implementation']=getattr(engine.model.torso.config,'_attn_implementation',None)
    metadata['engine_config']=dataclasses.asdict(engine.cfg)
    write_json(OUT/'metadata.json',metadata)
    emit({'phase':'load','seconds':load_seconds,'dtype':metadata['torso_dtype']})
except Exception:
    emit({'phase':'load_error','traceback':traceback.format_exc()});raise

all_records=[]

def check_response(resp):
    for answer in resp['answers'].values():
        if answer['type']=='choice':
            probs=answer['probabilities'];values=list(probs.values())
            assert all(math.isfinite(p) and 0<=p<=1 for p in values)
            assert abs(sum(values)-1)<0.0003,probs
            assert probs[answer['choice']]>=max(values)-0.0001
            expected=max(0,min(1,(len(values)*max(values)-1)/(len(values)-1)))
            assert abs(expected-answer['confidence'])<0.0002,(expected,answer)
        else:
            assert math.isfinite(answer['noul']) and 0<=answer['noul']<=1

def execute(phase,ident,state,question,**extra):
    request=SystemOneRequest(state=state,questions={'answer':question})
    # Mirror the actual engine tokenization: state with specials; suffix without specials.
    state_tokens=len(engine.tok(render_state(state),add_special_tokens=True)['input_ids'])
    suffix_tokens=len(engine.tok(render_question(request.questions['answer']).text,add_special_tokens=False)['input_ids'])
    try:
        torch.cuda.synchronize();start=time.perf_counter()
        response=engine.evaluate(request)
        torch.cuda.synchronize();elapsed=(time.perf_counter()-start)*1000
        resp=response.model_dump()
        check_response(resp)
        assert resp['usage']['input_tokens']==state_tokens+suffix_tokens
        record={'phase':phase,'id':ident,'model':args.model,'latency_ms':elapsed,'state_tokens':state_tokens,'question_tokens':suffix_tokens,'rendered_tokens':state_tokens+suffix_tokens,'request':request.model_dump(),'response':resp,**extra}
        all_records.append(record);emit(record)
        return record
    except Exception:
        emit({'phase':'request_error','requested_phase':phase,'id':ident,'request':request.model_dump(),'traceback':traceback.format_exc()});raise

first=dataset['choices'][0]
execute('first_request','first-request',first['state'],first['question'])
for item in dataset['choices']:
    execute('choice',item['id'],item['state'],item['question'],language=item['language'],expected=item['expected'],pair_id=item['pair_id'])
for item in dataset['negation']:
    for kind in ['ordinary','inverted']:
        execute('negation',item['id']+'-'+kind,item['state'],item[kind],language=item['language'],expected=item['expected_'+kind],pair_id=item['id'],question_kind=kind)

latency_inputs=[]
question=plan['latency']['question']
q=SystemOneRequest(state='',questions={'answer':question}).questions['answer']
q_tokens=len(engine.tok(render_question(q).text,add_special_tokens=False)['input_ids'])
for target in plan['latency']['target_rendered_tokens']:
    sentence=plan['latency']['state_sentence']
    # Select repeated complete sentences nearest the target, preserving natural text.
    candidates=[sentence*n for n in range(1,300)]
    lengths=[len(engine.tok(render_state(s),add_special_tokens=True)['input_ids'])+q_tokens for s in candidates]
    index=min(range(len(lengths)),key=lambda i:abs(lengths[i]-target))
    state=candidates[index]
    latency_inputs.append({'target_tokens':target,'actual_tokens':lengths[index],'state':state,'question':question})
    for i in range(plan['latency']['warmup_per_length']):execute('latency_warmup',f'{target}-warmup-{i+1}',state,question,target_tokens=target,iteration=i+1)
    for i in range(plan['latency']['repeats_per_length']):execute('latency',f'{target}-repeat-{i+1}',state,question,target_tokens=target,iteration=i+1)
write_json(OUT/'latency_inputs.json',latency_inputs)

summary={'model':args.model,'load_seconds':load_seconds,'first_request_ms':next(r['latency_ms'] for r in all_records if r['phase']=='first_request'),'choice':{},'negation':{},'latency':[],'error_count':0,'response_probability_checks':'passed every response; tolerate API rounding to four decimal places','percentile_method':'numpy.percentile(method="linear"), equivalent to interpolation at index (n-1)*q'}
for lang in ['en','ko']:
    rows=[r for r in all_records if r['phase']=='choice' and r['language']==lang]
    answers=[r['response']['answers']['answer'] for r in rows]
    correct=sum(a['choice']==r['expected'] for r,a in zip(rows,answers))
    summary['choice'][lang]={'correct':correct,'total':len(rows),'accuracy':correct/len(rows),'mean_max_probability':statistics.mean(max(a['probabilities'].values()) for a in answers),'mean_confidence':statistics.mean(a['confidence'] for a in answers),'errors':[{'id':r['id'],'expected':r['expected'],'actual':a['choice']} for r,a in zip(rows,answers) if a['choice']!=r['expected']]}
    rows=[r for r in all_records if r['phase']=='negation' and r['language']==lang]
    correct=[(r['response']['answers']['answer']['noul']>=0.5)==r['expected'] for r in rows]
    pair_ids=list(dict.fromkeys(r['pair_id'] for r in rows))
    pairs=[[r for r in rows if r['pair_id']==pid] for pid in pair_ids]
    both=sum(all((r['response']['answers']['answer']['noul']>=0.5)==r['expected'] for r in pair) for pair in pairs)
    summary['negation'][lang]={'correct_questions':sum(correct),'total_questions':len(rows),'question_accuracy':sum(correct)/len(rows),'both_correct_pairs':both,'total_pairs':len(pairs),'pair_accuracy':both/len(pairs),'mean_complement_deviation':statistics.mean(abs(sum(r['response']['answers']['answer']['noul'] for r in pair)-1) for pair in pairs),'errors':[{'id':r['id'],'expected':r['expected'],'p_true':r['response']['answers']['answer']['noul']} for r,c in zip(rows,correct) if not c]}
for target in plan['latency']['target_rendered_tokens']:
    rows=[r for r in all_records if r['phase']=='latency' and r['target_tokens']==target]
    values=[r['latency_ms'] for r in rows]
    probs=[r['response']['answers']['answer']['probabilities'] for r in rows]
    spans={k:max(p[k] for p in probs)-min(p[k] for p in probs) for k in probs[0]}
    summary['latency'].append({'target_tokens':target,'actual_rendered_tokens':rows[0]['rendered_tokens'],'state_tokens':rows[0]['state_tokens'],'question_tokens':rows[0]['question_tokens'],'n':len(values),'p50_ms':float(np.percentile(values,50,method='linear')),'p95_ms':float(np.percentile(values,95,method='linear')),'min_ms':min(values),'max_ms':max(values),'mean_ms':statistics.mean(values),'unique_returned_probability_vectors':len({json.dumps(p,sort_keys=True) for p in probs}),'max_returned_probability_span':max(spans.values())})
summary['peak_gpu_allocated_bytes']=torch.cuda.max_memory_allocated()
write_json(OUT/'summary.json',summary)
emit({'phase':'complete','summary':summary})
