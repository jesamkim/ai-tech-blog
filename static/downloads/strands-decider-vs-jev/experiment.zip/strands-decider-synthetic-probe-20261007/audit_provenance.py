"""Read-only post-run audit for the v19 process started before inline checks."""
import datetime,hashlib,json,subprocess
from pathlib import Path
import strands_decider
root=Path(__file__).resolve().parent
source=root/'source'
plan=json.loads((root/'plan.json').read_text())
imported=Path(strands_decider.__file__).resolve()
assert imported==source/'src'/'strands_decider'/'__init__.py'
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
status=subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
assert commit==plan['source_commit'] and not status
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit={'audited_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audit_kind':'Post-run read-only verification; not a pre-execution check','model':'v19','source_commit':commit,'source_clean':True,'imported_package_is_pinned_checkout':True,'imported_package_relative_to_experiment':str(imported.relative_to(root)),'original_execution_script_sha256':sha(root/'run_probe.py'),'module_sha256':{str(p.relative_to(source)):sha(p) for p in sorted((source/'src'/'strands_decider').rglob('*.py'))}}
path=root/'results'/'v19'/'post_run_provenance_audit.json'
with path.open('x') as f:f.write(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:v for k,v in audit.items() if k!='module_sha256'},indent=2))
