"""Download pinned public checkpoints; reuse existing manifest without overwriting it."""
import datetime, json, time
from pathlib import Path
from huggingface_hub import HfApi, snapshot_download

ROOT=Path(__file__).resolve().parent
plan=json.loads((ROOT/'plan.json').read_text())
public_path=ROOT/'models_resolved.json'
private_path=ROOT/'models_resolved_private.json'
existing=json.loads(public_path.read_text()) if public_path.exists() else None
if existing is not None and {r['model_id'] for r in existing}!=set(plan['model_ids']):
    raise ValueError('Existing model manifest does not match frozen plan; use a new experiment directory')
pins={r['model_id']:r for r in existing or []}
api=HfApi()
records=[]
for model_id in plan['model_ids']:
    start=time.perf_counter()
    revision=pins[model_id]['revision'] if model_id in pins else api.model_info(model_id).sha
    checkpoint=Path(snapshot_download(model_id,revision=revision))
    config_path=checkpoint/'strands_decider_config.json'
    if not config_path.exists():config_path=checkpoint/'hobson_config.json'
    config=json.loads(config_path.read_text())
    provenance=json.loads((checkpoint/'provenance.json').read_text()) if (checkpoint/'provenance.json').exists() else {}
    base_model=config['base_model']
    base_revision=config.get('base_revision') or provenance.get('base_model_revision')
    if not base_revision:raise ValueError('Refuse unpinned base model')
    if model_id in pins and (base_model!=pins[model_id]['base_model'] or base_revision!=pins[model_id]['base_revision']):
        raise ValueError('Pinned base provenance changed; refusing to proceed')
    snapshot_download(base_model,revision=base_revision,allow_patterns=['*.safetensors','*.json','*.jinja','*.model','*.txt'])
    record={'model_id':model_id,'revision':revision,'checkpoint':str(checkpoint),'base_model':base_model,'base_revision':base_revision,'download_or_cache_resolution_seconds':time.perf_counter()-start,'config':config,'resolved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    records.append(record)
    print(json.dumps({k:v for k,v in record.items() if k!='checkpoint'},ensure_ascii=False),flush=True)
public=[{k:v for k,v in r.items() if k!='checkpoint'} for r in records]
if existing is None:
    with public_path.open('x') as f:f.write(json.dumps(public,ensure_ascii=False,indent=2)+'\n')
if not private_path.exists():
    with private_path.open('x') as f:f.write(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
else:
    prior=json.loads(private_path.read_text())
    for old,new in zip(prior,records,strict=True):
        for key in ['model_id','revision','checkpoint','base_model','base_revision']:
            if old[key]!=new[key]:raise ValueError('Private manifest differs; use a new experiment directory')
if existing is not None:
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    replay_path=ROOT/f'download-replay-{stamp}.json'
    with replay_path.open('x') as f:f.write(json.dumps(public,ensure_ascii=False,indent=2)+'\n')
