# Strands Decider v19/v21: frozen synthetic probe

This is a small reproducible smoke test, not a benchmark. It uses 12 invented customer requests translated into English/Korean (24 classification inputs) and six explicit refund/no-refund states per language with ordinary/inverted questions (24 yes/no judgments). The dataset and plan were frozen before inference; SHA-256 hashes and UTC time are in `frozen_manifest.json`. No label, wording, threshold, or option order is tuned after observing model answers. Choice prompts and descriptions are English for both input languages. Negation questions match the state language, while the engine's template and default true/false option descriptions remain English.

The only execution target is one existing NVIDIA A10G GPU. No cloud endpoint is created, and no server is exposed. This test does not call Jev. It cannot establish Korean population performance or a Decider-versus-Jev quality/latency ranking.

## Reproduce

Use Linux with one compatible NVIDIA GPU and a working driver. Work inside a new experiment directory. The implementation was tested using the exact versions captured in `requirements-lock.txt`; Python and driver versions appear in each model's `metadata.json`.

```bash
git clone https://github.com/strands-labs/strands-decider.git source
git -C source checkout 3e94e9d84c620ed5a95f1a3310c3decb971e261c
uv venv --python 3.13.12 .venv
uv pip install --python .venv/bin/python -c requirements-lock.txt -e 'source[cuda]' torch==2.10.0 transformers==5.17.0 peft==0.21.0
uv pip install --python .venv/bin/python -c requirements-lock.txt setuptools wheel packaging ninja
# Set CUDA_HOME/PATH only if your nvcc is outside PATH.
uv pip install --python .venv/bin/python -c requirements-lock.txt causal-conv1d==1.7.0 --no-build-isolation
export HF_HOME="$PWD/cache/huggingface"
export TRITON_CACHE_DIR="$PWD/cache/triton"
export TORCHINDUCTOR_CACHE_DIR="$PWD/cache/torchinductor"
.venv/bin/python download_models.py
.venv/bin/python run_probe.py --model v19
.venv/bin/python run_probe.py --model v21
```

`download_models.py` resolves checkpoint revisions before inference and downloads each config's pinned base-model revision. When `models_resolved.json` already exists, its exact model/base revisions are automatically reused, and the public manifest is not overwritten. Re-resolve newer model versions only in a new experiment directory. Cached reruns write a separate download-replay log. The local-only `models_resolved_private.json` contains cache paths used by the runner; do not publish it. The public `models_resolved.json` omits those paths. Start with a fresh `results/` directory: the runner refuses to overwrite a prior raw run.

## Measurement

- Direct Python `SystemOneEngine.evaluate`, sequential batch size 1. `perf_counter` surrounds the call, with CUDA synchronization before and after. Engine tokenization is timed; request validation is outside the timed region. HTTP and network overhead are absent.
- Both models use a 4096-token ceiling and `strict_window=True`. State and rendered question are tokenized as the engine does; `usage.input_tokens` must match the recorded sum. No input in this experiment is truncated.
- The latency states repeat one English sentence. Complete sentences are repeated until the rendered total is nearest 128, 512, or 2048 tokens. The actual counts, not approximate targets, are the numbers to cite. Each length has three warmups and twenty timed calls. Long repeated inputs do not test long-document understanding.
- Model download/cache resolution time, model load time, and first request are distinct fields. First request can include CUDA/Triton initialization and compilation. The v21 process can reuse on-disk kernel caches created by v19; first-request times are not a controlled cold-start comparison.
- p50/p95 use NumPy linear percentile interpolation at index `(n-1) * quantile`. Twenty sequential repetitions are too few for a production tail-latency claim. The table describes this run only.
- The model uses evaluation mode with seed 42. Deterministic algorithms are not forced. Returned probability vectors across latency repeats are counted after the API's four-decimal rounding; equality does not establish bitwise determinism.
- Choice confidence is `(N * max_probability - 1) / (N - 1)`, clamped to [0, 1]. It is not the top probability. The runner checks range, probability sum, argmax and confidence consistency with rounding tolerance. `noul` is P(true); the fixed decision rule is `P(true) >= 0.5`.
- No confidence thresholds are fitted or evaluated here. Clear hand-written labels and option order are fixed, and the small dataset does not estimate production calibration.

## Evidence files

`dataset.json`, `plan.json`, `frozen_manifest.json`: pre-inference evidence.

`run_probe.py`, `download_models.py`: full execution scripts.

`results/v19/` and `results/v21/`: exact requests/responses and per-request timings (`raw.jsonl`), environment (`metadata.json`), latency state text (`latency_inputs.json`), and metrics (`summary.json`).

Runtime errors, if any, are recorded in raw JSONL and process logs; do not silently replace a failed run. Dependency-install logs are operational setup evidence and are separate from model inference errors.

The scripts and dataset are original experiment material. The upstream source/model licenses apply to upstream software and weights; they are not bundled here.

The published runner also verifies the imported package path, clean source checkout, and exact source commit; it records its own hash and every upstream Python module hash. The first v19 run began before these checks were added. Its original execution script is retained under `execution_scripts/`, and a separate read-only `post_run_provenance_audit.json` verifies the same source and module identity. The dataset, measurement loop, labels, model weights, and numerical results were not changed by the provenance-only revision.

## Execution order, initialization, and clocks

The recorded execution order was **v19 first, then v21**, in separate Python processes on the same existing GPU. Both runs set the same experiment-local `HF_HOME=cache/huggingface`, `TRITON_CACHE_DIR=cache/triton`, and `TORCHINDUCTOR_CACHE_DIR=cache/torchinductor`. Those directories were preserved between runs. Thus v21 could reuse Triton disk cache entries built during v19; a much shorter first call is not evidence of faster cold start. The cache directory was newly introduced for this experiment, but OS page cache and other driver-level caches were not flushed.

The first request in both runs was `route-01-en`: the English duplicate-subscription-charge state and the fixed three-category question from `dataset.json`. It was timed separately and excluded from the 20-repetition latency distributions. All timing requests were sequential, with no overlapping experiment process; v19 completed before v21 started. Model order and token-length order were fixed, not randomized or interleaved. GPU clocks were neither locked nor sampled during the timing loop, so clock/thermal drift is an uncontrolled factor. Initial inspection showed no other GPU process. These conditions do not support interpreting small differences as a causal version speed advantage.

`execution_notes.json` records the command environment, run order, evidence timestamps and methodological limits. `execution_scripts/run_probe_v19.py` and `run_probe_v21.py` are the exact scripts whose hashes match their execution evidence. The final `run_probe.py` adds a conservative missing-kernel guard after review; missing symbols now result in `optimized_kernel_selection_verified=false` rather than being skipped. `verification.json` independently checks that all four required kernel symbols were present and selected optimized implementations in both actual runs. This guard change does not alter inference or timing.

`requirements-lock.txt` is the observed dependency freeze with the editable project path replaced by a comment. Installation uses it as a constraint file; the project itself is installed from the pinned `source/` checkout. Public setup logs replace the experiment host path with `<EXPERIMENT_DIR>`; model responses and numerical timings are unchanged. Original operational logs remain in the private working directory.
